<!DOCTYPE html>
<html>
  <head>
    <title>Расписание</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="container">
      <h1>Расписание</h1>
      <table>
        <tr>
          <th>День недели</th>
          <th>Предмет</th>
          <th>Преподаватель</th>
        </tr>
        <?php
          // подключаемся к базе данных
          $servername = "-localhost";
          $username = "root";
          $password = "root";
          $dbname = "школа";

          $conn = mysqli_connect($servername, $username, $password, $dbname);

          // проверяем соединение
          if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
          }

          // выполняем запрос к базе данных
          $sql = "SELECT day, subject, teacher FROM schedule";
          $result = mysqli_query($conn, $sql);

          // выводим результат запроса на страницу
          if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
              echo "<tr><td>" . $row["day"]. "</td><td>" . $row["subject"]. "</td><td>" . $row["teacher"]. "</td></tr>";
            }
          } else {
            echo "0 results";
          }

          // закрываем соединение
          mysqli_close($conn);
        ?>
      </table>
      <form>
        <h2>Вход</h2>
        <label for="username">Имя пользователя:</label>
        <input type="text" id="username" name="username" required>
        <label for="password">Пароль:</label>
        <input type="password" id="password" name="password" required>
        <input type="submit" value="Войти">
      </form>
    </div>
    <script src="script.js"></script>
  </body>
</html>

