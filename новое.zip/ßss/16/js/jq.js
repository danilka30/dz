jQuery(document).ready(function(){
alert("ваша версия"+jQuery.fn.jquery)});
