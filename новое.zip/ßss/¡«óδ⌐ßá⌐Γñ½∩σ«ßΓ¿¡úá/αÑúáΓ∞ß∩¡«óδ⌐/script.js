const form = document.querySelector('form');

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  authenticateUser(username, password);
});

function authenticateUser(username, password) {
  // отправляем запрос на сервер для аутентификации пользователя
  // в случае успеха, перенаправляем пользователя на страницу соответствующей роли
}
